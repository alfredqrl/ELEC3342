# ------------------------------------------------------------------------------
# Course: ELEC3342
# File: input_generator
# Description: Produce Morse code testbench for symdet
# Created By: yizhao
#
# Copyright (C) 2021  Yizhao Gao
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.
# ------------------------------------------------------------------------------
import numpy as np

def fix_unit_no_error(sequence):
    symbols = sequence.split(" ")
    u = 3
    binary_sequence = []
    for sym in symbols:
        if sym == "dot":
            binary_sequence.append([1 for i in range(u)])
        elif sym == "dash":
            binary_sequence.append([1 for i in range(3*u)])
        elif sym == "sg":
            binary_sequence.append([0 for i in range(u)])
        elif sym == "lg":
            binary_sequence.append([0 for i in range(3*u)])
        elif sym == "wg":
            binary_sequence.append([0 for i in range(7*u)])
        else:
            raise ValueError()
    combined_sequence = np.hstack(binary_sequence).T
    return combined_sequence.astype(int)


def fix_unit_fix_error(sequence):
    symbols = sequence.split(" ")
    u = 3
    binary_sequence = []
    Error = 2
    for sym in symbols:
        err = np.random.randint(low=-Error, high=Error+1)
        #print(sym, err)
        if sym == "dot":
            binary_sequence.append([1 for i in range(u + err)])
        elif sym == "dash":
            binary_sequence.append([1 for i in range(3*u + err)])
        elif sym == "sg":
            binary_sequence.append([0 for i in range(u + err)])
        elif sym == "lg":
            binary_sequence.append([0 for i in range(3*u + err)])
        elif sym == "wg":
            binary_sequence.append([0 for i in range(7*u + err)])
        else:
            raise ValueError()

    combined_sequence = np.hstack(binary_sequence).T
    return combined_sequence.astype(int)



def unit_2to4_fix_error(sequence):
    symbols = sequence.split(" ")
    U = 2
    binary_sequence = []
    for i in range(3):
        u = U + i
        Error = u - 1
        #print("U is:", u)
        for sym in symbols:
            err = np.random.randint(low=-Error, high=Error+1)
            #print(sym, err)
            if sym == "dot":
                s = [1 for i in range(u + err)]
            elif sym == "dash":
                s = [1 for i in range(3*u + err)]
            elif sym == "sg":
                s = [0 for i in range(u + err)]
            elif sym == "lg":
                s = [0 for i in range(3*u + err)]
            elif sym == "wg":
                s = [0 for i in range(7*u + err)]
            else:
                raise ValueError()
            binary_sequence.append(s)

    combined_sequence = np.hstack(binary_sequence).T
    return combined_sequence.astype(int)





def random_unit_fix_error(sequence):
    symbols = sequence.split(" ")
    U = [6, 10, 15, 5, 8]
    binary_sequence = []
    for u in U:
        Error = u - 1
        #print("U is:", u)
        for sym in symbols:
            err = np.random.randint(low=-Error, high=Error+1)
            #print(sym, err)
            if sym == "dot":
                s = [1 for i in range(u + err)]
            elif sym == "dash":
                s = [1 for i in range(3*u + err)]
            elif sym == "sg":
                s = [0 for i in range(u + err)]
            elif sym == "lg":
                s = [0 for i in range(3*u + err)]
            elif sym == "wg":
                s = [0 for i in range(7*u + err)]
            else:
                raise ValueError()
            binary_sequence.append(s)

    combined_sequence = np.hstack(binary_sequence).T
    return combined_sequence.astype(int)


if __name__ == '__main__':

    H = "dot sg dot sg dot sg dot"
    E = "dot"
    L = "dot sg dash sg dot sg dot"
    O = "dash sg dash sg dash"
    W = "dot sg dash sg dash"
    R = "dot sg dash sg dot"
    D = "dash sg dot sg dot"
    K = "dash sg dot sg dash"
    U = "dot sg dot sg dash"
    lg = " lg "
    wg = " wg "
    sequence = H + lg + E + lg + L + lg + L + lg + O + wg + H + lg + K + lg + U +" wg"

    s = fix_unit_no_error(sequence)
    np.savetxt("L0.txt", s, fmt='%i', delimiter="\n")
    s1 = fix_unit_fix_error(sequence)
    np.savetxt("L1.txt", s1, fmt='%i', delimiter="\n")
    s2 = unit_2to4_fix_error(sequence)
    np.savetxt("L2.txt", s2, fmt='%i', delimiter="\n")
    s3 = random_unit_fix_error(sequence)
    np.savetxt("L3.txt", s3, fmt='%i', delimiter="\n")
