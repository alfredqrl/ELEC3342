### Testbench for symdet
- The test morse code sequence are "Hello HKU". 
- The corresponding symbols are ".... . .-.. .-.. --- / .... -.- ..-"
#### Include .txt file in the simluation    
- Right click simulation sources and choose **Add source**
- Add or create simulation sources
- Add File; Choose File of Type as **All Files**
- Select the .txt files
