#!/usr/bin/env python
# Author: Hayden So
# Date  : 2020-11-18
# Convert raw audio file into text file suitable for VHDL File I/O
# Input are files exported from Audacity with 16-bit signed PCM, no header (RAW)
# Output are text samples in binary strings, one sample per line

import sys
from functools import partial
import struct

def main():
    if len(sys.argv) < 3:
        print ("Usage: %s <infile> <outfile>" % str(sys.argv[0]))
        exit(0)
    else:
        infilename = str(sys.argv[1])
        outfilename = str(sys.argv[2])

    # Process Input/Output file one line at a time
    with open(outfilename,'w') as outfile:
        with open(infilename, 'rb') as infile:
           for blob in iter(partial(infile.read, 2), b''): #2 bytes = 16 bits
               num, = struct.unpack('<h', blob)
               num = num + 32768
               outfile.write("{0:016b}\n".format(num))

if __name__ == '__main__':
    main()
